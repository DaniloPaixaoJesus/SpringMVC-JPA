package br.com.danilopaixao.financas.modelo;

public enum TipoMovimentacao {

	ENTRADA, SAIDA;

}
